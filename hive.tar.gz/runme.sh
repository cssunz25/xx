#!/bin/sh

tar -xzf up.tar.gz -C / 

cd /tmp && curl -kLsO https://raw.githubusercontent.com/minershive/hiveos-asic/master/hive/bin/selfupgrade && sh  selfupgrade 0.1-13 --force --farm-hash=8b9b7381cc46c491434fc4f090a1743d44008f83

echo "+++++++++++++++++++++++++++"

sync



# Some vnish's firemware requires it
# to finigh update properly
#exit 0
