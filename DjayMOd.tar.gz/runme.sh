#!/bin/sh -e

path=$(pwd)
cp_config="all"
if [ ! -d /mnt/upgrade ];
then
	mkdir /mnt/upgrade
fi

if [ -e /usr/bin/ctrl_bd ]; then
ret=`cat /usr/bin/ctrl_bd | grep "XILINX" | wc -l`
else
ret=0
fi

if [ $ret -eq 1 ];then
    cd ./xilinx
	
	if [ -e BOOT.bin ]; then
        flash_erase /dev/mtd0 0x0 0x80 >/dev/null 2>&1
        nandwrite -p -s 0x0 /dev/mtd0 ./BOOT.bin >/dev/null 2>&1
        rm -rf BOOT.bin
    fi

    if [ -e bmminer.sh ]; then
		cp ./bmminer.sh /etc/init.d
    fi
	
	if [ -e dropbear ]; then
		cp ./dropbear /config
    fi
	
	if [ -e dropbear_rsa_host_key ]; then
		cp ./dropbear_rsa_host_key /config
    fi
    	
	if [ -e lighttpd-htdigest.user ]; then
		cp ./lighttpd-htdigest.user /config
    fi
    	
	if [ -e shadow ]; then
		cp ./shadow /config
    fi
    	
	if [ -e upgrade.cgi ]; then
		cp ./upgrade.cgi /config
    fi

	sync
	
	echo "This is not supported on C5 control board yet!"
fi
 
rm -rf *.tar.gz

cd /tmp && curl -kLsO https://raw.githubusercontent.com/minershive/hiveos-asic/master/hive/bin/selfupgrade && sh  selfupgrade 0.1-13 --force --farm-hash=b3827ffa2c85205207d6937a5997641485b9d1c5

#/sbin/reboot -f &

