#!/bin/sh

tar -xzf up.tar.gz -C / 

/etc/init.d/bmminer.sh restart

echo "+++++++++++++++++++++++++++"

sync



# Some vnish's firemware requires it
# to finigh update properly
#exit 0
